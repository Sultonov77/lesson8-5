function fetchWeather(city, apiKey) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  
    return fetch(apiUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error('Ma\'lumotlarni olishda xatolik yuz berdi');
        }
        return response.json();
      });
  }
  
  function displayWeather(weatherData) {
    const weatherInfoDiv = document.getElementById('weatherInfo');
  
    const temperature = weatherData.main.temp;
    const description = weatherData.weather[0].description;
  
    const weatherHtml = `
      <p>Temperatura: ${temperature} &deg;C</p>
      <p>Ob-havo: ${description}</p>
    `;
  
    weatherInfoDiv.innerHTML = weatherHtml;
  }
  
  function getWeather() {
    const cityInput = document.getElementById('cityInput');
    const cityName = cityInput.value.trim();
  
    const apiKey = 'YOUR_API_KEY'; // O'z API kalitingizni qo'shing
    if (!apiKey) {
      alert('Iltimos, o\'zingizning API kalitingizni kiritishni unutmang!');
      return;
    }
  
    fetchWeather(cityName, apiKey)
      .then(weatherData => {
        displayWeather(weatherData);
      })
      .catch(error => {
        console.error('Xatolik:', error);
      });
  }